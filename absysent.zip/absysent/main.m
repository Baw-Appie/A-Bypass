#include <compression.h>
#include <mach-o/fat.h>
#include <mach-o/loader.h>
#include <mach-o/nlist.h>
#include <sys/mman.h>
#include <sys/stat.h>
#import <sys/syscall.h>
#import <string.h>
#include <CommonCrypto/CommonCrypto.h>
#include <mach/mach.h>
#include <dirent.h>
#import <os/log.h>
#import "patchfinder64.h"

int decompress_kernel(FILE *inputfh, FILE* outputfh, FILE *kppfh, bool quiet);

@interface APLog : NSObject
+ (void)log:(NSString *)format, ...;
@end
@implementation APLog
+ (void)log:(NSString *)format, ... {
    static os_log_t log;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        const char *identifier = "com.rpgfarm";
        log = os_log_create(identifier, "log");
    });

    va_list ap;
    va_start (ap, format);
    NSString *message = [[NSString alloc] initWithFormat:format arguments:ap];
    va_end (ap);

    os_log(log, "[APLog] %{public}@", message);
    printf("[APLog] %s\n", [message UTF8String]);
}
@end

#define _assert(test, message, fatal) if (!(test)) { \
    printf("Test failed: %s\n", message.UTF8String); \
    exit(1); \
}

static void *load_bytes2(FILE *obj_file, off_t offset, uint32_t size) {
    void *buf = calloc(1, size);
    fseek(obj_file, offset, SEEK_SET);
    fread(buf, size, 1, obj_file);
    return buf;
}

uint32_t find_macho_header(FILE *file) {
    uint32_t off = 0;
    uint32_t *magic = load_bytes2(file, off, sizeof(uint32_t));
    while ((*magic & ~1) != 0xFEEDFACE) {
        printf("Search bytes..\n");
        off++;
        magic = load_bytes2(file, off, sizeof(uint32_t));
    }
    return off - 1;
}

#define SYSENT_ADDRESS 0xfffffff0078a28c0

__attribute__((constructor))
int main(int argc, char *argv[], char *envp[]) {

    NSFileManager *manager = [NSFileManager defaultManager];

    const char *original_kernel_cache_path = "/System/Library/Caches/com.apple.kernelcaches/kernelcache";
    const char *decompressed_kernel_cache_path = "/Library/BawAppie/ABypass/kernelResourceFinder";

    if(![manager fileExistsAtPath:@(decompressed_kernel_cache_path)]) {
        printf("No decompressed kernel cache.\n");
    	FILE *original_kernel_cache = fopen(original_kernel_cache_path, "rb");
        FILE *const decompressed_kernel_cache = fopen(decompressed_kernel_cache_path, "w+b");
        _assert(original_kernel_cache != NULL, @"No kernel cache.", true);
        printf("Start decompressed kernel cache.\n");
        _assert(decompress_kernel(original_kernel_cache, decompressed_kernel_cache, NULL, true) == ERR_SUCCESS, @"Unable to decompress kernelcache.", true);
        fclose(decompressed_kernel_cache);
        fclose(original_kernel_cache);
    } else {
        printf("Decompressed kernel cache is exists.\n");
    }

    _assert(init_kernel(NULL, 0, decompressed_kernel_cache_path) == ERR_SUCCESS, @"Failed to initialize patchfinder64 (init_kernel).", true);
    printf("InitKernel complete.\n");

    uint64_t sysent = find_proc_find();
    _assert(sysent != 0, @"Failed to find sysent.", true);
    printf("systent finded!\n");


    printf("done.\n");

	return 1;
}
